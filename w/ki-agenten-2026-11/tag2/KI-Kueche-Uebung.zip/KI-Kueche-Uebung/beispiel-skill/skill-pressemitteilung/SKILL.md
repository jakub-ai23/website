---
name: pressemitteilung-musterfeld
description: Schreibt und überarbeitet Pressemitteilungen im Hausstil der Musterfeld Saatzucht GmbH (fiktiv) – Nachricht zuerst, höchstens 3.000 Zeichen, jede Zahl mit Herkunft, genau ein Zitat, Boilerplate unverändert. Verwenden, wenn eine Pressemitteilung für Musterfeld geschrieben, geprüft oder überarbeitet werden soll.
---

# Pressemitteilung im Musterfeld-Stil

Quelle aller Regeln: `eingang/b-stilregeln-und-pressemitteilung-saatgut.md`, Teil 1 (Stilregeln). Die Belege zitieren den Regeltext; wo der Entwurf in Teil 2 gegen die Regel verstößt, ist das als Gegenbeispiel angegeben.

## Regeln

1. **Nachricht zuerst.** Der erste Satz sagt, was neu ist, für wen und ab wann. Hintergrund erst danach.
   - Beleg: „Erst die Nachricht, dann der Hintergrund. Der erste Satz sagt, was neu ist, für wen und ab wann.“
   - Gegenbeispiel (Entwurf): „… bringt mit 'Aurelia' die beste Winterweizensorte ihrer Geschichte auf den Markt.“ – kein „ab wann“, kein „für wen“.
2. **Länge: höchstens 3.000 Zeichen** inklusive Leerzeichen, ohne Boilerplate. Vor Abgabe zählen.
   - Beleg: „Höchstens 3.000 Zeichen inklusive Leerzeichen, ohne Boilerplate.“
3. **Keine Superlative ohne Beleg.** Statt Wertung die Zahl aus dem Versuch, mit Quelle.
   - Beleg: „Nicht "die beste Sorte", sondern die Zahl aus dem Versuch, mit Quelle.“
   - Gegenbeispiel (Entwurf): „die beste Winterweizensorte ihrer Geschichte“, „eine außergewöhnlich starke Sorte“.
4. **Jede Zahl mit Herkunft:** Versuch, Jahr, Ort. Zahl ohne Herkunft streichen – auch qualitative Leistungsaussagen brauchen eine Versuchsangabe oder fliegen raus.
   - Beleg: „Jede Zahl mit Herkunft: Versuch, Jahr, Ort. Ohne Herkunft fliegt die Zahl raus.“
   - Gegenbeispiel (Entwurf): „Auch bei Trockenheit bleibt sie stabil“ – ohne Versuchszahl.
5. **Fachbegriffe einmal erklären**, beim ersten Vorkommen, in einem Halbsatz.
   - Beleg: „Fachbegriffe einmal erklären, beim ersten Vorkommen, in einem Halbsatz.“
   - Gegenbeispiel (Entwurf): „Gelbrost“ ohne Erklärung.
6. **Genau ein Zitat**, von der Geschäftsführung oder der Züchtungsleitung, höchstens zwei Sätze, als freigegeben markiert (Freigabe vor Veröffentlichung einholen).
   - Beleg: „Zitat: genau eines, von der Geschäftsführung oder der Züchtungsleitung, höchstens zwei Sätze, freigegeben.“
   - Gegenbeispiel (Entwurf): Zitat von Dr. Erika Muster mit drei Sätzen.
7. **Keine Wiederholung** derselben Aussage in anderen Worten.
   - Beleg: „Keine Wiederholung derselben Aussage in anderen Worten.“
   - Gegenbeispiel (Entwurf): „'Aurelia' ist eine sehr starke Sorte und überzeugt in jeder Hinsicht.“ wiederholt den ersten Absatz.
8. **Schreibweise:** Sortennamen in einfachen Anführungszeichen ('Aurelia'); Firmenname beim ersten Mal ganz („Musterfeld Saatzucht GmbH“), danach nur „Musterfeld“.
   - Beleg: „Sortennamen in einfachen Anführungszeichen ('Aurelia'), Firmenname beim ersten Mal ganz, danach "Musterfeld".“
9. **Schluss:** Boilerplate und Pressekontakt, unverändert, wörtlich wie unten.
   - Beleg: „Am Ende: Boilerplate (unten) und Pressekontakt, unverändert.“

## Boilerplate (wörtlich übernehmen)

> Die Musterfeld Saatzucht GmbH züchtet seit 1952 Getreide und Ölsaaten für den mitteleuropäischen Anbau. Sitz: Musterdorf (fiktiv).

Pressekontakt: in der Musterdatei nicht angegeben – Platzhalter `[Pressekontakt]` setzen, nicht erfinden.

## Ablauf

1. Fakten sammeln: Was ist neu, für wen, ab wann? Welche Zahlen mit Versuch/Jahr/Ort liegen vor?
2. Ersten Satz nach Regel 1 schreiben.
3. Text schreiben, jede Zahl und Leistungsaussage gegen Regel 3 und 4 prüfen.
4. Zitat (max. 2 Sätze) einbauen, mit Hinweis „Freigabe ausstehend“, falls nicht freigegeben.
5. Zeichen zählen (ohne Boilerplate), Wiederholungen streichen.
6. Boilerplate und Pressekontakt anhängen.

## Nicht geregelt

- Gendern: Die Stilregeln sagen nichts dazu. Nicht eigenmächtig entscheiden, sondern nachfragen.
- Inhalt und Form des Pressekontakts.
