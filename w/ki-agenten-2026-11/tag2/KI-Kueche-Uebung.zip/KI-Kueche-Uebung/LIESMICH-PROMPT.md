# KI-Küche: ein Auftrag, drei Köche, ein Vorkoster

Created: 2026-11-12 · Last updated: 2026-11-12
KI-Agenten-Workshop, Tag 2 · Alle Dateien im Ordner "eingang" sind frei erfunden.

## So geht's
1. Diesen Ordner entpacken.
2. Claude Cowork: den Ordner "KI-Kueche-Uebung" freigeben. ChatGPT oder Copilot: die vier Dateien aus "eingang" hochladen.
3. Den Prompt unten komplett kopieren und einfügen.
4. Danach vergleichen: Ihr Skill gegen "beispiel-skill/skill-pressemitteilung/SKILL.md".

## Prompt (Version 2)

```text
Du arbeitest im freigegebenen Ordner. Im Unterordner "eingang" liegen vier erfundene Musterdateien. Bitte erledige vier Aufgaben und schreib alles als Dateien in einen neuen Unterordner "ausgang".

1. SKILL BAUEN: Lies "b-stilregeln-und-pressemitteilung-saatgut.md". Baue daraus einen Skill, der Pressemitteilungen in genau diesem Stil schreibt. Lege ihn als Ordner "ausgang/skill-pressemitteilung/" mit einer Datei SKILL.md an (oben name und description, darunter die Regeln als Liste, jede Regel mit einem Beleg aus der Musterdatei).

2. DREI AUFGABEN PARALLEL: Lass drei Teilaufgaben gleichzeitig laufen, wenn du das kannst, jede als eigener Arbeiter. WICHTIG: Gib jedem Arbeiter die Originaldateien mit, die er braucht, nicht nur eine Zusammenfassung.
   a) Rechercheur: Lies "d-recherche-auftrag-mit-quellenregeln.md" und schreib "ausgang/1-recherche.md" (nur Quellen, die du wirklich geöffnet hast, mit Link).
   b) Texter: Schreib mit deinem Skill aus Aufgabe 1 eine neue Pressemitteilung zu einem frei erfundenen Anlass, "ausgang/2-pressemitteilung.md".
   c) Normen-Bearbeiter: Arbeite die Normänderung aus "c-managementhandbuch-kapitel-mit-normaenderung.md" in das Kapitel ein, "ausgang/3-handbuch-neu.md", Änderungen markiert.

3. PRÜFER: Prüfe danach 2-pressemitteilung.md gegen die Stilregeln aus Aufgabe 1 UND gegen die Originaldatei "b-stilregeln-und-pressemitteilung-saatgut.md". Schreib "ausgang/4-pruefbericht.md": jede Regel mit erfüllt / nicht erfüllt und Zitat.

4. PROTOKOLL: Schreib "ausgang/0-protokoll.md": Welche Aufgaben liefen wirklich parallel, welche nacheinander? Welche Werkzeuge hast du benutzt (Dateien lesen, Dateien schreiben, Web, Code)? Wo bist du an Grenzen gestoßen? Wie lange hat jede Aufgabe ungefähr gedauert? Erfinde nichts: Was du nicht weißt, schreib als "unbekannt".
```

## Je nach Werkzeug
- **Claude Cowork:** läuft wie oben, mit echten Unteragenten.
- **ChatGPT:** schreibt die Dateien meist zum Herunterladen statt in einen Ordner. Ob es parallel arbeitet, steht im Protokoll.
- **Copilot:** Hier sind Sie der Chef. Ein Agent je Aufgabe, Sie geben die Ergebnisse von Hand weiter.

## Danach prüfen
- Was bemängelt Ihr Prüfer?
- Steht im Protokoll ehrlich, was parallel lief?
- Merksatz: Es geht selten etwas beim Arbeiten verloren. Es geht bei der Übergabe verloren.
