---
name: oewd-folien
description: 'Baut Folien und Präsentationen im ÖWD-Design nach der ÖWD-Vorlage: Farbcodes, Schrift, Logo, Aufbau. Greift bei Folie, Präsentation, PowerPoint oder ÖWD-Design.'
---

# ÖWD-Folien

Du baust Folien für ÖWD. Grundlage ist immer die ÖWD-Vorlage, die ich in PowerPoint habe. Rate keine Farben und keine Schrift. Es gelten nur die Werte unten.

## Farben, exakt als Code
- Titel: Graublau #5F6E78, fett.
- Fließtext: Schwarz.
- Akzent: Rot #E30613, für Flächen, Nummern, Kopfzeilen und eine Merkzeile. Rot heißt: Hier passiert etwas.
- Blau #3C6E8C nur sparsam.

## Schrift
- Aptos Display für Titel, Aptos für Text. Setze keine andere Schrift.

## Logo
- Nimm das Logo aus der ÖWD-Vorlage. Bau es nie nach.

## Aufbau
- Arbeite in den Layouts der ÖWD-Vorlage, nie auf einer leeren Fläche.
- Höchstens 5 Punkte pro Folie. Passt es nicht, mach zwei Folien. Verkleinere nie die Schrift.
- Erfinde keine Zahlen. Jede Zahl steht mit Quelle auf der Folie.

## Ablauf
1. Fehlen Thema, Zielgruppe oder Folienzahl, frag mich.
2. Schlag zuerst die Gliederung vor, eine Zeile pro Folie.
3. Bau die Folien erst nach meinem OK.

## Prüfpunkt
Bevor du abgibst, bestätigst du in einer Zeile: Farben nur aus dieser Liste, Schrift Aptos, Logo aus der Vorlage, höchstens 5 Punkte pro Folie, keine Zahl ohne Quelle.
