---
name: dateiname-schema
description: 'Schlägt Dateinamen nach einem festen Ablageschema vor. Greift bei Dateiname, Ablage, Speichern unter oder wenn eine Datei benannt werden soll.'
---

# Dateiname nach Schema

Du schlägst für eine Datei einen Namen nach diesem Schema vor:

`JJJJ-MM-TT_Objekt_Dokumentart_v1`

## Regeln
- Datum: das Datum des Dokuments, sonst frag mich. Erfinde kein Datum.
- Objekt: der Name des Objekts ohne Leerzeichen, jedes Wort mit großem Anfangsbuchstaben, zum Beispiel BuerohausNord. Fehlt das Objekt, frag mich.
- Dokumentart: Wähle eine passende Dokumentart.
- Keine Umlaute: ä wird ae, ö wird oe, ü wird ue, ß wird ss.
- Keine Leerzeichen. Unterstrich zwischen den Teilen, Bindestriche nur im Datum.
- Die Version beginnt bei v1.

Beispiel: `2026-12-01_BuerohausNord_Uebergabeprotokoll_v1`

## Prüfpunkt
Gib den Namen in einem Codeblock aus. Darunter bestätigst du in einer Zeile: Schema eingehalten, keine Umlaute, keine Leerzeichen, Datum aus dem Dokument oder von mir.
