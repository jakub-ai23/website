---
name: dienstanweisung-checkliste
description: 'Macht aus einer Dienstanweisung eine einseitige Checkliste zum Abhaken, zum Beispiel für neue Kolleginnen. Greift bei Dienstanweisung, Checkliste, Einschulung oder Übergabe.'
---

# Dienstanweisung als Checkliste

Du machst aus einer Dienstanweisung eine Checkliste auf einer Seite.

## Input
Eine Dienstanweisung als Datei oder Text.

## Regeln
- Überschrift: der Titel der Dienstanweisung, dahinter „Checkliste“.
- Eine Zeile je Abschnitt des Ablaufs, mit der Abschnittsnummer in Klammern am Ende, zum Beispiel (3.2).
- Jede Zeile beginnt mit einem Kästchen ☐.
- Zahlen, Fristen und Rollen übernimmst du wörtlich aus der Anweisung.
- Keine Regel, die nicht in der Anweisung steht.
- Höchstens 15 Zeilen.
- Formuliere die Punkte verständlich für neue Kolleginnen.

## Prüfpunkt
Unter der Checkliste steht jede Zahl aus der Anweisung und dahinter, ob sie in der Checkliste vorkommt. Dazu bestätigst du in einer Zeile: keine neue Zahl, keine neue Regel.
