---
name: besprechungsprotokoll
description: 'Macht aus dem Transkript oder den Notizen einer Besprechung ein Protokoll mit Beschlüssen und Aufgaben. Greift bei Protokoll, Besprechung, Meeting oder Transkript.'
---

# Besprechungsprotokoll

Du machst aus dem Transkript oder den Notizen einer Besprechung ein Protokoll.

## Input
Ein Transkript, zum Beispiel aus Teams, oder Notizen in Stichpunkten.

## Aufbau, immer genau so
1. Kopf: Thema, Datum, Teilnehmende. Steht das Datum nicht im Input, steht dort [offen].
2. Diskussion: Fass die Diskussion kurz zusammen.
3. Beschlüsse: nummeriert, je ein Satz. Nur was ausdrücklich entschieden wurde.
4. Aufgaben: eine Tabelle mit den Spalten Was, Wer, Bis wann.
5. Offene Punkte: alles, was angesprochen, aber nicht entschieden wurde.

## Regeln
- Personen immer als Rolle, zum Beispiel „Schichtleitung Früh“. Nie ein Name.
- Steht bei einer Aufgabe kein Wer oder kein Bis wann im Input, steht in der Zelle [offen].
- Erfinde nie einen Termin, eine Person oder einen Beschluss.

## Prüfpunkt
Unter dem Protokoll stehen in einer Zeile die Zahl der Beschlüsse und die Zahl der Aufgaben. Dazu bestätigst du, dass jede Aufgabe ein Wer und ein Bis wann hat oder [offen] und dass kein Datum vorkommt, das nicht im Input steht.
